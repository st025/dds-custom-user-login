<div class="username">
    <label for="user_login" class="hide"><?php _e('Username or Email'); ?>: </label>
    <input type="text" name="user_login" value="" size="20" id="user_login" tabindex="1001" />
</div>
<div class="login_fields">
    <?php do_action('login_form', 'resetpass'); ?>
    <input type="submit" name="user-submit" value="<?php _e('Reset my password'); ?>" class="user-submit" tabindex="1002" />
    <?php
    if(isset($_GET['reset'])) {
        $reset = $_GET['reset'];
        if($reset == true) {
            echo '<p>A message will be sent to your email address.</p>';
        }
    }
    ?>
    <input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>?reset=true" />
    <input type="hidden" name="user-cookie" value="1" />
</div>