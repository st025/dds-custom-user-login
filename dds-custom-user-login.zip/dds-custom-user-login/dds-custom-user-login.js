function openTab(evt, tabName) {
    var i, tab_content_login, tablinks;
    tab_content_login = document.getElementsByClassName("tab_content_login");
    for (i = 0; i < tab_content_login.length; i++) {
        tab_content_login[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}


// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();