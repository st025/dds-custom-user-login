<?php
defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); //blocking direct access to your plugin PHP files

/*
    Plugin Name: DDS Custom User Login
    Plugin URI: http://webdataseo.com
    Description: A plugin that provides user login , registration and password change option in the wp frontend as a shortcode
    Version: 1.0
    Author: Sofia Tsenekidou
    Author URI: http://www.webdataseo.com
    Text Domain: dds-custom-user-login
    Domain Path: /lang
    License: GPLv2
    Copyright (C) 2014-2017 Sofia Tsenekidou
*/
?>

<!-- Custom Login/Register/Password Code @ https://digwp.com/2010/12/login-register-password-code/ -->
<!-- Theme Template Code -->

<?php
function dds_custom_user_login_shortcodes (){
    global $reset, $register;
    global $user_login, $user_email;
    global $user_ID, $user_identity;

?>
<div id="login-register-password">

    <?php
    if (!$user_ID) { ?>
        <div class="tab">
            <button class="tablinks" onClick="openTab(event,'tab1_login')" id="defaultOpen">Login</button>
            <button class="tablinks" onClick="openTab(event,'tab2_login')">Register</a></button>
            <button class="tablinks" onClick="openTab(event,'tab3_login')">Forgot?</a></button>
        </div>
        <div class="tab_container_login">
            <div id="tab1_login" class="tab_content_login">

                <?php
                if(isset($_GET['register'])) {
                    $register = $_GET['register'];
                    if ($register == true) { ?>

                        <h3>Success!</h3>
                        <p>Check your email for the password and then return to log in.</p>
                        <?php
                    }
                }
                if(isset($_GET['reset'])) {
                    $reset = $_GET['reset'];
                    if ($reset == true) { ?>

                        <h3>Success!</h3>
                        <p>Check your email to reset your password.</p>
                        <?php
                    }
                }
                if((!isset($_GET['reset'])) && (!isset($_GET['register'])) ){?>
                    <h3>Have an account?</h3>
                    <p>Log in or sign up! It&rsquo;s fast &amp; <em>free!</em></p>
                <?php
                } ?>

                <form method="post" action="<?php bloginfo('url'); ?>/wp-login.php" class="wp-user-form">
                   <?php require('inc/tabs-login.php'); //add login tab form?>
                </form>
            </div>
            <div id="tab2_login" class="tab_content_login">
                <h3>Register for this site!</h3>
                <p>Sign up now for the good stuff.</p>
                <form method="post" action="<?php echo site_url('wp-login.php?action=register', 'login_post'); ?>" class="wp-user-form">
                    <?php require('inc/tabs-register.php'); //add register tab form ?>

                </form>
            </div>
            <div id="tab3_login" class="tab_content_login">
                <h3>Lose something?</h3>
                <p>Enter your username or email to reset your password.</p>
                <form method="post" action="<?php echo site_url('wp-login.php?action=lostpassword', 'login_post'); ?>" class="wp-user-form">
                    <?php require('inc/tabs-lostpassword.php'); //add lostpassword tab form ?>
                </form>
            </div>
        </div>

    <?php
    } else { // is logged in ?>

        <div class="sidebox">
            <h3>Welcome, <?php echo $user_identity; ?></h3>
            <div class="usericon">
                <?php global $userdata; echo get_avatar($userdata->ID, 60); ?>

            </div>
            <div class="userinfo">
                <p>You&rsquo;re logged in as <strong><?php echo $user_identity; ?></strong></p>
                <p>
                    <a href="<?php echo wp_logout_url('index.php'); ?>">Log out</a> |
                    <?php if (current_user_can('manage_options')) {
                        echo '<a href="' . admin_url() . '">' . __('Admin') . '</a>'; } else {
                        echo '<a href="' . admin_url() . 'profile.php">' . __('Profile') . '</a>'; } ?>

                </p>
            </div>
        </div>

    <?php } ?>

</div>

<!-- Custom Login/Register/Password Code @ https://digwp.com/2010/12/login-register-password-code/ -->
<?php } //end function

add_shortcode( 'dds_custom_user_login', 'dds_custom_user_login_shortcodes' );
//to add the shortcode in the frontend
// 1. [dds_custom_user_login] shortcode it will display the tab forms in the frontend
// and to make sure Wordpress is calling shortcode in sidebars
add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode', 11);

// the below function adds a css anda .js (jquery) file inside our plugin which is used for the layout of forms and the javascript
function dds_custom_user_login_frontend_styles(){
wp_enqueue_style('dds_custom_user_login_css',plugins_url('dds-custom-user-login/dds-custom-user-login.css'));
wp_enqueue_script('dds_custom_user_login_js', plugins_url( 'dds-custom-user-login/dds-custom-user-login.js'), array('jquery'), '', true );
}
add_action('wp_enqueue_scripts','dds_custom_user_login_frontend_styles',2); //it is adding the css and js files style to the website front-end

// the below function adds a css anda .js (jquery) file inside our plugin which is used for the layout of forms and the javascript
function dds_custom_user_login_backend_styles(){
    wp_enqueue_style('dds_custom_user_login_css',plugins_url('dds-custom-user-login/dds-custom-user-login.css'));
    wp_enqueue_script('dds_custom_user_login_js', plugins_url( 'dds-custom-user-login/dds-custom-user-login.js'), array('jquery'), '', true );
}
add_action('admin_head','dds_custom_user_login_backend_styles'); //it is adding the css and js files style to the website front-end

?>